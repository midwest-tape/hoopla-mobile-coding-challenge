package com.hoopladigital.codingchallenge

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun BrowseView(viewModel: BrowseViewModel = viewModel()) {

}