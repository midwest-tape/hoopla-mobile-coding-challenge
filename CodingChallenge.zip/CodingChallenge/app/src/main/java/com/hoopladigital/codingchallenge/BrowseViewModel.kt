package com.hoopladigital.codingchallenge

import androidx.lifecycle.ViewModel


class BrowseViewModel : ViewModel() {

}